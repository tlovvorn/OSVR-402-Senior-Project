#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
//#include <string>
using namespace std;

int main(int argc, char** argv){
	int seed;
	if(argc < 2){
		cout<< "No seed was given, using time for random number initialization\n";
		seed = time(NULL);
	}else{
		seed = atoi(argv[1]);
	}
	
	int minSys, maxSys, minDst, maxDst, minPls, maxPls;
	int sysRng, dstRng, plsRng, trials;
	cin >> minSys;
	cin >> maxSys;
	cin >> minDst;
	cin >> maxDst;
	cin >> minPls;
	cin >> maxPls;
	cin >> trials;
	
	sysRng = maxSys - minSys;
	dstRng = maxDst - minDst;
	plsRng = maxPls - minPls;
	
	ofstream out;
	out.open("netTest.txt");
	if(!out.is_open()){
		cerr << "Could not create and/or open the output file\n";
		return 0;
	}
	srand(seed);
	int tsys, tdst, tpls;
	out << 120 << " " << 80 << " " << 60 << endl;
	for(int i=0; i < trials-1; i++){
		tsys = rand() % sysRng + minSys;
		tdst = rand() % dstRng + minDst;
		tpls = rand() % plsRng + minPls;
		out << tsys << " " << tdst << " " << tpls << endl;
	}
	out.close();
	return 1;
}
