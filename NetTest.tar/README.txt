The file that creates the test data sets is makeVitals.cpp, along with its corresponding 
executable. It takes a single command line input, being the seed used for the random number
generator.

The remaining input it takes are min and max values for systolic, diastolic, and pulse. The
order of the inputs are alternating min and max in the order of systolic, diastolic, pulse.
For example:

min systolic
max systolic
min diastolic

and so on. The last input the executable takes is the number of test trials it will create.

